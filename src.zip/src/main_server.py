# main_server.py
from __future__ import annotations
import asyncio
import math
import multiprocessing as mp
from typing import List

from server.controller.server_controller import ServerController
from common.config import PER_SHARD_CAP, make_sequential_endpoints, even_distribution

def _ask_int(prompt: str, default: int) -> int:
    raw = input(f"{prompt} [{default}]: ").strip()
    return default if raw == "" else int(raw)

def _ask_str(prompt: str, default: str) -> str:
    raw = input(f"{prompt} [{default}]: ").strip()
    return default if raw == "" else raw

async def _run_one(host: str, port: int, shard_clients: int, group_size: int):
    srv = ServerController(total_clients=shard_clients, group_size=group_size, host=host, port=port)
    await srv.start()

def _server_process(host: str, port: int, shard_clients: int, group_size: int):
    asyncio.run(_run_one(host, port, shard_clients, group_size))

def main():
    print("=== SERVIDOR SHARDED AUTO ===")
    total_clients = _ask_int("Número TOTAL de clientes (N)", 60000)
    group_size    = _ask_int("Tamaño de barrio/grupo (V)", 100)
    host          = _ask_str("HOST de escucha", "0.0.0.0")
    base_port     = _ask_int("Puerto base", 8888)

    # Auto: 6k por shard
    shards = max(1, math.ceil(total_clients / PER_SHARD_CAP))
    shard_sizes = even_distribution(total_clients, shards)
    endpoints = make_sequential_endpoints(host, base_port, shards)

    print(f"Creando {shards} proceso(s) servidor. Puertos {base_port}..{base_port+shards-1}")
    procs: List[mp.Process] = []
    for (h, p), n in zip(endpoints, shard_sizes):
        pr = mp.Process(target=_server_process, args=(h, p, n, group_size), daemon=False)
        pr.start()
        procs.append(pr)

    for pr in procs:
        pr.join()

if __name__ == "__main__":
    mp.freeze_support()
    main()
