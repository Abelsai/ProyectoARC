"""
main_prototipo.py

Versión corregida para Windows:
- Tkinter (GUI) corre en el hilo principal.
- El servidor y los clientes (asyncio) corren en un hilo secundario.
"""

import asyncio
import threading
from server.controller.server_controller import ServerController
from client.controller.client_controller import ClientController
from common.utils import generate_client_id
from common.config import NUM_CLIENTES


async def run_simulation(server: ServerController, num_clients: int):
    """Ejecuta la simulación completa."""
    print(f"Iniciando simulación con {num_clients} clientes...")

    # Iniciar servidor
    server_task = asyncio.create_task(server.start())
    await asyncio.sleep(1)

    # Crear clientes
    clients = [ClientController(generate_client_id()) for _ in range(num_clients)]
    client_tasks = [asyncio.create_task(c.connect()) for c in clients]

    await asyncio.gather(*client_tasks, return_exceptions=True)
    server_task.cancel()
    print("Simulación finalizada.")


def asyncio_thread(server: ServerController, num_clients: int):
    """Ejecuta asyncio (servidor + clientes) en otro hilo."""
    asyncio.run(run_simulation(server, num_clients))


def main():
    num_clients = NUM_CLIENTES
    server = ServerController(min_clients=num_clients)

    # Lanza asyncio en un hilo secundario
    t = threading.Thread(target=asyncio_thread, args=(server, num_clients), daemon=True)
    t.start()

    # Ejecuta GUI en el hilo principal
    server.gui.run()

    # Cuando cierras la GUI, se cierra todo
    print("GUI cerrada, finalizando programa...")


if __name__ == "__main__":
    main()
