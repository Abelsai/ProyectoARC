import tkinter as tk
import math
from typing import List, Dict

class DynamicDashboard:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Simulación de Estaciones Eléctricas")
        self.root.geometry("1000x750")

        # Lienzo principal
        self.canvas = tk.Canvas(self.root, bg="white", width=980, height=560)
        self.canvas.pack(padx=10, pady=(10, 6))

        # Leyenda
        self.legend = tk.Canvas(self.root, bg="#fafafa", width=980, height=40, highlightthickness=0)
        self.legend.pack(padx=10, pady=(0, 6))
        self._draw_legend()

        # Logs
        self.log_box = tk.Text(self.root, height=8, state="disabled", bg="#f4f4f4")
        self.log_box.pack(fill="x", padx=10, pady=(0, 10))

        # Estados → color
        self.colores = {"NORMAL": "green", "ALERTA": "yellow", "INCIDENCIA": "red"}

        # Datos
        self.barrios: List[List[str]] = []  # cada barrio contiene una lista de client_ids
        self.node_map: Dict[str, int] = {}  # client_id → canvas_item_id (óvalo)

        # Parámetros de layout (se recalculan al cambiar datos)
        self.grid_cols = 1
        self.grid_rows = 1

        # Redibujar al redimensionar ventana
        self.canvas.bind("<Configure>", lambda _e: self._recalculate_layout())

    # ─────────────────────────────────────────────
    # Utilidad para llamadas thread-safe desde asyncio
    # ─────────────────────────────────────────────
    def _safe(self, fn, *args, **kwargs):
        """Agenda una llamada en el hilo de Tk (thread-safe)."""
        self.root.after(0, lambda: fn(*args, **kwargs))

    # ─────────────────────────────────────────────
    # Leyenda
    # ─────────────────────────────────────────────
    def _draw_legend(self):
        self.legend.delete("all")
        items = [("NORMAL", "green"), ("ALERTA", "yellow"), ("INCIDENCIA", "red")]
        x = 10
        for label, color in items:
            self.legend.create_oval(x, 10, x+18, 28, fill=color, outline="#333")
            self.legend.create_text(x+30, 19, anchor="w", text=label, font=("Arial", 10, "bold"))
            x += 110

    # ─────────────────────────────────────────────
    # API pública (puede llamarse desde servidor/asyncio)
    # ─────────────────────────────────────────────
    def add_barrio(self):
        self._safe(self._add_barrio_ui)

    def add_cliente(self, barrio_idx: int, client_id: str):
        self._safe(self._add_cliente_ui, barrio_idx, client_id)

    def update_state(self, client_id: str, state: str):
        self._safe(self._update_state_ui, client_id, state)

    def log(self, msg: str):
        self._safe(self._log_ui, msg)

    def run(self):
        self.root.mainloop()

    # ─────────────────────────────────────────────
    # Implementación UI (solo se llama dentro del hilo Tk)
    # ─────────────────────────────────────────────
    def _add_barrio_ui(self):
        self.barrios.append([])
        self._recalculate_layout()
        self._log_ui(f"🏘️ Nuevo barrio creado ({len(self.barrios)})")

    def _add_cliente_ui(self, barrio_idx: int, client_id: str):
        # Crear barrio si hace falta
        while barrio_idx >= len(self.barrios):
            self.barrios.append([])
        # Añadir cliente y redibujar
        self.barrios[barrio_idx].append(client_id)
        self._recalculate_layout()
        self._log_ui(f"[+] Cliente {client_id} añadido a barrio {barrio_idx+1}")

    def _update_state_ui(self, client_id: str, state: str):
        if client_id not in self.node_map:
            # aún no dibujado (puede llegar INFO muy pronto)
            return
        color = self.colores.get(state, "gray")
        self.canvas.itemconfig(self.node_map[client_id], fill=color)

    def _log_ui(self, msg: str):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", msg + "\n")
        self.log_box.configure(state="disabled")
        self.log_box.see("end")

    # ─────────────────────────────────────────────
    # Layout y dibujo
    # ─────────────────────────────────────────────
    def _recalculate_layout(self):
        total_barrios = len(self.barrios)
        if total_barrios == 0:
            self.canvas.delete("all")
            return

        # Cuadrícula para barrios (≈ cuadrada)
        self.grid_cols = math.ceil(math.sqrt(total_barrios))
        self.grid_rows = math.ceil(total_barrios / self.grid_cols)

        self._redraw_all()

    def _redraw_all(self):
        self.canvas.delete("all")
        self.node_map.clear()

        W = max(self.canvas.winfo_width(), 200)
        H = max(self.canvas.winfo_height(), 200)
        margin = 20

        cell_w = (W - 2 * margin) / self.grid_cols
        cell_h = (H - 2 * margin) / self.grid_rows

        for b_idx, barrio in enumerate(self.barrios):
            # Celda destino
            gx = b_idx % self.grid_cols
            gy = b_idx // self.grid_cols
            x0 = margin + gx * cell_w
            y0 = margin + gy * cell_h

            # Título del barrio
            self.canvas.create_text(x0 + 6, y0 + 12, anchor="w",
                                    text=f"Barrio {b_idx+1}", font=("Arial", 10, "bold"))

            # Área interna para nodos (dejamos 26 px arriba para el título)
            pad = 10
            area_x = x0 + pad
            area_y = y0 + 26
            area_w = cell_w - 2 * pad
            area_h = cell_h - 26 - pad

            # Calcular rejilla óptima para que quepan todos los nodos
            n = max(1, len(barrio))
            cols, rows, node_size, gap = self._best_grid(n, area_w, area_h)

            # Dibujar nodos
            i = 0
            for client_id in barrio:
                cx = i % cols
                cy = i // cols
                px = area_x + cx * (node_size + gap) + gap
                py = area_y + cy * (node_size + gap) + gap
                node_id = self.canvas.create_oval(px, py, px + node_size, py + node_size,
                                                  fill="lightgray", outline="#333")
                self.node_map[client_id] = node_id
                i += 1

            # Borde de la celda del barrio (opcional, para separar visualmente)
            self.canvas.create_rectangle(x0 + 2, y0 + 2, x0 + cell_w - 2, y0 + cell_h - 2,
                                         outline="#ddd")

    @staticmethod
    def _best_grid(n: int, area_w: float, area_h: float):
        """
        Dado n nodos y un área disponible, calcula (cols, rows, node_size, gap)
        que maximizan el tamaño del nodo manteniendo separación y quepan todos.
        """
        # Espacio entre nodos
        min_gap, max_gap = 4, 10
        best = (1, n, 8, min_gap)  # cols, rows, size, gap (fallback)

        # Probamos distintas columnas posibles (hasta n o límite por píxeles)
        max_cols = max(1, min(n, int(area_w // 12)))
        for cols in range(1, max_cols + 1):
            rows = math.ceil(n / cols)

            # probamos varios gaps y nos quedamos con el mayor tamaño posible
            for gap in (6, 8, 10, 4):
                size_w = (area_w - (cols + 1) * gap) / cols
                size_h = (area_h - (rows + 1) * gap) / rows
                size = min(size_w, size_h)

                if size >= 6:  # tamaño mínimo visible
                    # preferimos el mayor nodo posible
                    if size > best[2]:
                        best = (cols, rows, int(size), gap)

        return best
