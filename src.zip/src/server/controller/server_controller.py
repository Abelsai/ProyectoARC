"""
Servidor del sistema de estaciones eléctricas con GUI dinámica.
Calcula métricas globales de tiempo y latencia al finalizar.
"""

import asyncio, json
from common.protocol import make_message, MessageType
from common.config import SERVER_HOST, SERVER_PORT, MAX_PER_BARRIO
from server.gui_dynamic import DynamicDashboard
from common.logger import logger



class ServerController:
    def __init__(self, min_clients: int):
        # Estructuras principales
        self.clients = {}        # id → writer
        self.neighbours = {}     # id → lista de vecinos
        self.barrios = []        # lista de listas de clientes
        self.min_clients = min_clients
        self.simulation_started = False

        self.client_metrics = {}

        
        self.gui = DynamicDashboard()
        self.gui.log("[SERVIDOR] Iniciado")

    # -------------------------------------------------------------------------
    async def start(self):
        """Arranca el servidor y acepta conexiones entrantes."""
        server = await asyncio.start_server(self.handle_client, SERVER_HOST, SERVER_PORT)
        self.gui.log(f"[SERVIDOR] Escuchando en {SERVER_HOST}:{SERVER_PORT}")
        async with server:
            await server.serve_forever()

    # -------------------------------------------------------------------------
    async def handle_client(self, reader, writer):
        """Gestiona la conexión y los mensajes de un cliente."""
        msg = json.loads((await reader.readline()).decode())


        cid = msg["client_id"]
        self.clients[cid] = writer
        self._assign_to_barrio(cid)
        self.gui.log(f"[+] Cliente {cid} conectado")

        # Inicia simulación al alcanzar el mínimo requerido
        if not self.simulation_started and len(self.clients) >= self.min_clients:
            self.simulation_started = True
            await self.start_simulation()

        try:
            while data := await reader.readline():
                msg = json.loads(data.decode())
                await self.process_message(msg)
        except Exception as e:
            self.gui.log(f"[!] Error en {cid}: {e}")
        finally:
            self.gui.log(f"[-] Cliente {cid} desconectado (EOF)")
            self.clients.pop(cid, None)
            writer.close()
            await writer.wait_closed()

    # -------------------------------------------------------------------------
    def _assign_to_barrio(self, cid: str):
        """Agrupa clientes en barrios y define sus vecinos."""
        if not self.barrios or len(self.barrios[-1]) >= MAX_PER_BARRIO:
            self.barrios.append([cid])
            self.gui.add_barrio()
        else:
            self.barrios[-1].append(cid)

        barrio_idx = len(self.barrios) - 1
        self.gui.add_cliente(barrio_idx, cid)
        self._update_neighbors_for_barrio(self.barrios[-1])

    def _update_neighbors_for_barrio(self, barrio: list[str]):
        for c in barrio:
            self.neighbours[c] = [n for n in barrio if n != c]

    # -------------------------------------------------------------------------
    async def start_simulation(self):
        """Envía START con los vecinos a todos los clientes."""
        self.gui.log(f"[SERVIDOR] Simulación iniciada ({len(self.clients)} clientes)")
        for cid, w in self.clients.items():
            msg = make_message(MessageType.START, "server", {
                "neighbours": self.neighbours.get(cid, [])
            })
            try:
                w.write((json.dumps(msg) + "\n").encode())
                await w.drain()
            except Exception:
                self.gui.log(f"[!] No se pudo iniciar cliente {cid}")

    # -------------------------------------------------------------------------
    async def process_message(self, msg):
        """Procesa mensajes enviados por los clientes."""
        cid, t = msg["client_id"], msg["type"]

        # ---------------- INFO ----------------
        if t == MessageType.INFO.value:
            data = msg["data"]
            estado = data["state"]
            es_reactivo = data.get("reactive", False)
            logger.info(f"INFO recibido de {cid}: estado={estado}")

            self.gui.update_state(cid, estado)
            
            # Propagar solo si NO es reactivo
            if not es_reactivo and estado in ("INCIDENCIA", "NORMAL"):
                for n in self.neighbours.get(cid, []):
                    if n in self.clients:
                        logger.info(f"Reenviando INFO {estado} de {cid} → {n}")
                        w = self.clients[n]
                        try:
                            w.write((json.dumps({
                                "type": MessageType.INFO.value,
                                "client_id": cid,
                                "data": data
                            }) + "\n").encode())
                            await w.drain()
                        except Exception:
                            self.gui.log(f"[!] Error enviando INFO a {n}")


        # ---------------- ACK ----------------
        elif t == MessageType.ACK.value:
            dest = msg["data"].get("ack_to")
            logger.info(f"ACK recibido de {cid} para {dest}")
            if dest in self.clients:
                logger.info(f"Reenviando ACK de {cid} → {dest}")
                w = self.clients[dest]
                ack_msg = {
                    "type": MessageType.ACK.value,
                    "client_id": cid,
                    "data": {"from": cid}
                }
                try:
                    w.write((json.dumps(ack_msg) + "\n").encode())
                    await w.drain()
                except Exception:
                    self.gui.log(f"[!] Error reenviando ACK a {dest}")

        # ---------------- END ----------------
        elif t == MessageType.END.value:
            data = msg["data"]
            logger.info(f"END recibido de {cid}")
            state_times = data.get("state_times", {})
            avg_latency = data.get("avg_latency", 0.0)
            self.client_metrics[cid] = {
                **state_times,
                "avg_latency": avg_latency
            }
            self.gui.log(f"[{cid}] métricas recibidas (latencia={avg_latency*1000:.2f} ms)")

            if len(self.client_metrics) == len(self.clients):
                await self._finalize_simulation()

    # -------------------------------------------------------------------------
    async def _finalize_simulation(self):
        """Calcula métricas globales y muestra resultados en GUI."""
        self.gui.log("[SERVIDOR] Calculando métricas globales...")

        total_normal = total_alerta = total_incid = 0.0
        total_latency = 0.0
        count = len(self.client_metrics)

        # Acumular métricas globales
        for m in self.client_metrics.values():
            total_normal += m.get("NORMAL", 0.0)
            total_alerta += m.get("ALERTA", 0.0)
            total_incid += m.get("INCIDENCIA", 0.0)
            total_latency += m.get("avg_latency", 0.0)

        if count > 0:
            total_time = total_normal + total_alerta + total_incid or 1.0
            pct_n = total_normal / total_time
            pct_a = total_alerta / total_time
            pct_i = total_incid / total_time
            avg_latency = total_latency / count

            self.gui.log("───────────── [MÉTRICAS GLOBALES] ─────────────")
            self.gui.log(f"Clientes totales: {count}")
            self.gui.log(f"Tiempo medio → NORMAL={pct_n:.1%}, ALERTA={pct_a:.1%}, INCIDENCIA={pct_i:.1%}")
            self.gui.log(f"Latencia media global: {avg_latency*1000:.2f} ms")
            self.gui.log("───────────────────────────────────────────────")

        # Enviar END a los clientes
        end_msg = make_message(MessageType.END, "server", {"msg": "Simulación completada"})
        for cid, w in self.clients.items():
            try:
                w.write((json.dumps(end_msg) + "\n").encode())
                await w.drain()
            except Exception:
                self.gui.log(f"[!] No se pudo enviar END a {cid}")

        await asyncio.sleep(2)
        self.gui.log("[SERVIDOR] ✅ Simulación completada")
