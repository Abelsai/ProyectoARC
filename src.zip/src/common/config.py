# common/config.py
from __future__ import annotations
from typing import List, Tuple

# Buffers grandes = menos syscalls y menos backpressure (probado estable)
BUFFER_SIZE = 65536  # 64 KB

# Capacidad por shard (proceso servidor)
PER_SHARD_CAP = 6000

# Parámetros de rampa (lado cliente)
DEFAULT_BATCH_SIZE = 200        # conexiones por oleada
DEFAULT_BATCH_DELAY_MS = 50     # pausa entre oleadas (ms)

def make_sequential_endpoints(host: str, base_port: int, shards: int) -> List[Tuple[str, int]]:
    """Genera [(host, base_port), (host, base_port+1), ...]."""
    return [(host, base_port + i) for i in range(shards)]

def even_distribution(total: int, buckets: int) -> List[int]:
    """Reparte 'total' lo más uniforme posible en 'buckets'."""
    if buckets <= 0:
        return []
    base = total // buckets
    extra = total % buckets
    return [base + (1 if i < extra else 0) for i in range(buckets)]
