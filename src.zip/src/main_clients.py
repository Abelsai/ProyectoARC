# main_clients.py
from __future__ import annotations
import asyncio
import multiprocessing as mp
import math
from typing import List, Tuple

from client.controller.client_controller import ClientController
from common.config import (
    PER_SHARD_CAP,
    DEFAULT_BATCH_SIZE, DEFAULT_BATCH_DELAY_MS,
    make_sequential_endpoints, even_distribution
)

def _ask_str(prompt: str, default: str) -> str:
    raw = input(f"{prompt} [{default}]: ").strip()
    return default if raw == "" else raw

def _ask_int(prompt: str, default: int) -> int:
    raw = input(f"{prompt} [{default}]: ").strip()
    return default if raw == "" else int(raw)

async def _connect_one(host: str, port: int, iterations: int):
    cli = ClientController(host=host, port=port, iterations=iterations)
    try:
        await cli.connect()
    except Exception:
        pass

async def _launch_for_endpoint(host: str, port: int, count: int, iterations: int,
                               batch_size: int, batch_delay_ms: int):
    tasks: List[asyncio.Task] = []
    remaining = count
    while remaining > 0:
        this_batch = min(batch_size, remaining)
        for _ in range(this_batch):
            tasks.append(asyncio.create_task(_connect_one(host, port, iterations)))
        remaining -= this_batch
        await asyncio.sleep(batch_delay_ms / 1000.0)
    await asyncio.gather(*tasks, return_exceptions=True)

def _client_process(endpoints: List[Tuple[str,int]], per_endpoint_counts: List[int],
                    iterations: int, batch_size: int, batch_delay_ms: int):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    coros = []
    for (host, port), cnt in zip(endpoints, per_endpoint_counts):
        if cnt > 0:
            coros.append(_launch_for_endpoint(host, port, cnt, iterations, batch_size, batch_delay_ms))
    loop.run_until_complete(asyncio.gather(*coros))

def split_counts_for_processes(per_endpoint_counts: List[int], processes: int) -> List[List[int]]:
    """Devuelve por-proceso -> [cnt_ep0, cnt_ep1, ...] con reparto uniforme."""
    M = len(per_endpoint_counts)
    per_proc = [[0]*M for _ in range(processes)]
    for ep_idx, ep_total in enumerate(per_endpoint_counts):
        left = ep_total
        i = 0
        while left > 0:
            per_proc[i][ep_idx] += 1
            left -= 1
            i = (i + 1) % processes
    return per_proc

def main():
    print("=== CLIENTES SHARDED AUTO ===")
    server_ip     = _ask_str("IP/host del servidor", "127.0.0.1")
    base_port     = _ask_int("Puerto base del servidor", 8888)
    total_clients = _ask_int("Número total de clientes (N)", 60000)
    iterations    = _ask_int("Número de iteraciones por cliente (S)", 1)
    processes     = _ask_int("Nº de procesos clientes en este portátil", 8)
    batch_size    = _ask_int("Tamaño de lote (rampa)", DEFAULT_BATCH_SIZE)
    batch_delay   = _ask_int("Pausa entre lotes (ms)", DEFAULT_BATCH_DELAY_MS)

    # Auto: 6k por shard (asegúrate de lanzar el servidor con el mismo N)
    shards = max(1, math.ceil(total_clients / PER_SHARD_CAP))
    per_endpoint_counts = even_distribution(total_clients, shards)
    endpoints = make_sequential_endpoints(server_ip, base_port, shards)

    per_proc_matrix = split_counts_for_processes(per_endpoint_counts, processes)

    print(f"Conectando {total_clients} clientes en {shards} puerto(s): {base_port}..{base_port+shards-1}")
    procs: List[mp.Process] = []
    for i in range(processes):
        p = mp.Process(target=_client_process,
                       args=(endpoints, per_proc_matrix[i], iterations, batch_size, batch_delay),
                       daemon=False)
        p.start()
        procs.append(p)

    for p in procs:
        p.join()

if __name__ == "__main__":
    mp.freeze_support()
    main()
