"""
Cliente del sistema de estaciones eléctricas.
Estados: NORMAL, ALERTA, INCIDENCIA.
Mide latencia media de ACKs y tiempos por estado.
"""

import asyncio, json, random, time
from common.protocol import make_message, MessageType
from common.config import SERVER_HOST, SERVER_PORT, NUM_ITERATIONS


class ClientController:
    def __init__(self, cid: str):
        self.id = cid
        self.reader = None
        self.writer = None

        self.state = "NORMAL"
        self._state_since = time.perf_counter()
        self.state_time = {"NORMAL": 0.0, "ALERTA": 0.0, "INCIDENCIA": 0.0}

        self.neighbours = []
        self.pending_acks = set()
        self.waiting_for_acks = False
        self.latencies = []  # tiempos de ACK (s)

    # ---------------- MÉTRICAS ----------------
    def _accumulate_state_time(self, now: float):
        """Suma tiempo en el estado actual."""
        dt = now - self._state_since
        self.state_time[self.state] += dt
        self._state_since = now

    def _set_state(self, new_state: str):
        """Actualiza estado y registra cambio temporal."""
        if new_state != self.state:
            now = time.perf_counter()
            self._accumulate_state_time(now)
            self.state = new_state

    def _finalize_state_times(self):
        """Finaliza conteo de tiempo en cada estado."""
        now = time.perf_counter()
        self._accumulate_state_time(now)
        return self.state_time

    # ---------------- CONEXIÓN ----------------
    async def connect(self):
        """Establece conexión con el servidor."""
        self.reader, self.writer = await asyncio.open_connection(SERVER_HOST, SERVER_PORT)
        assert self.reader is not None and self.writer is not None, "Error: conexión no establecida"

        join_msg = make_message(MessageType.JOIN, self.id)
        self.writer.write((json.dumps(join_msg) + "\n").encode())
        await self.writer.drain()
        print(f"[{self.id}] Conectado al servidor")

        await self.listen_server()

    # ---------------- ESCUCHA ----------------
    async def listen_server(self):
        """Escucha y procesa mensajes del servidor."""
        assert self.reader is not None

        while data := await self.reader.readline():
            msg = json.loads(data.decode())
            msg_type = msg.get("type")

            if msg_type == MessageType.START.value:
                self.neighbours = msg["data"].get("neighbours", [])
                print(f"[{self.id}] Vecinos asignados: {len(self.neighbours)}")
                asyncio.create_task(self.run_simulation())

            elif msg_type == MessageType.INFO.value:
                sender = msg.get("client_id")
                neighbor_state = msg["data"].get("state")
                await self._handle_info(sender, neighbor_state)

            elif msg_type == MessageType.ACK.value:
                sender = msg["data"].get("from")
                await self._handle_ack(sender)

            elif msg_type == MessageType.END.value:
                print(f"[{self.id}] Finalización recibida del servidor")
                break

        assert self.writer is not None
        self.writer.close()
        await self.writer.wait_closed()

    # ---------------- PROCESAMIENTO DE MENSAJES ----------------
    async def _handle_info(self, sender: str, neighbor_state: str):
        assert self.writer is not None

        reactive = False 

        if neighbor_state == "INCIDENCIA" and self.state == "NORMAL":
            await asyncio.sleep(random.uniform(0.1, 0.3))
            self._set_state("ALERTA")
            reactive = True  # ← este cambio es por reacción
            await self._notify_server_state(reactive)

        elif neighbor_state == "NORMAL" and self.state == "ALERTA":
            await asyncio.sleep(random.uniform(0.1, 0.3))
            self._set_state("NORMAL")
            reactive = True
            await self._notify_server_state(reactive)

        # ACK
        ack_msg = make_message(MessageType.ACK, self.id, {"ack_to": sender})
        self.writer.write((json.dumps(ack_msg) + "\n").encode())
        await self.writer.drain()

    async def _handle_ack(self, sender: str):
        """Confirma recepción de ACKs esperados."""
        if sender in self.pending_acks:
            self.pending_acks.remove(sender)
            if not self.pending_acks:
                self.waiting_for_acks = False

    # ---------------- SIMULACIÓN ----------------
    async def run_simulation(self):
        """Ciclo principal de simulación de estados."""
        assert self.writer is not None

        for _ in range(NUM_ITERATIONS):
            if self.waiting_for_acks or self.state == "ALERTA":
                await asyncio.sleep(0.2)
                continue

            # NORMAL → INCIDENCIA  
            if self.state == "NORMAL" and random.random() < 0.001:
                self._set_state("INCIDENCIA")
                self.waiting_for_acks = True
                await self._send_info_and_wait_acks()
                await asyncio.sleep(random.uniform(3.0, 5.0))

            # INCIDENCIA → NORMAL
            elif self.state == "INCIDENCIA" and random.random() < 0.05:
                self._set_state("NORMAL")
                self.waiting_for_acks = True
                await self._send_info_and_wait_acks()
                await asyncio.sleep(random.uniform(3.0, 5.0))

            await asyncio.sleep(random.uniform(0.4, 0.8))

        # Envío de métricas finales
        state_times = self._finalize_state_times()
        avg_latency = sum(self.latencies) / len(self.latencies) if self.latencies else 0.0
        msg = make_message(MessageType.END, self.id, {
            "state_times": state_times,
            "avg_latency": avg_latency
        })
        assert self.writer is not None
        self.writer.write((json.dumps(msg) + "\n").encode())
        await self.writer.drain()
        print(f"[{self.id}] Métricas enviadas (latencia media: {avg_latency*1000:.2f} ms)")

    # ---------------- ENVÍO Y MEDICIÓN ----------------
    async def _send_info_and_wait_acks(self):
        """Envía INFO y mide latencia hasta recibir todos los ACKs."""
        assert self.writer is not None
        start_time = time.perf_counter()
        
        self.pending_acks = set(self.neighbours)
        await self._notify_server_state()

        try:
            await asyncio.wait_for(self._wait_for_acks(), timeout=10.0)
        except asyncio.TimeoutError:
            print(f"[{self.id}] Timeout: {len(self.pending_acks)} ACK(s) pendientes")

        latency = time.perf_counter() - start_time
        self.latencies.append(latency)
        self.waiting_for_acks = False

    async def _wait_for_acks(self):
        """Espera a que lleguen todos los ACKs pendientes."""
        while self.pending_acks:
            await asyncio.sleep(0.1)
            
    async def _notify_server_state(self, reactive=False):
        assert self.writer is not None
        msg = make_message(MessageType.INFO, self.id, {
            "state": self.state,
            "reactive": reactive
        })
        self.writer.write((json.dumps(msg) + "\n").encode())
        await self.writer.drain()
